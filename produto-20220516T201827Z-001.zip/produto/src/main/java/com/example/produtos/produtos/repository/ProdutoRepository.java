package com.example.produtos.produtos.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.produtos.produtos.model.Produtos;

public interface ProdutoRepository extends CrudRepository<Produtos,Long>{

}
