package com.example.produtos.produtos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.produtos.produtos.model.Produtos;
import com.example.produtos.produtos.repository.ProdutoRepository;



@Controller
public class ProdutoController {
	
	@Autowired
	private ProdutoRepository er;
    
    
	@ResponseBody
    @RequestMapping(value = { "/lista"}, method = RequestMethod.GET)
    public ModelAndView listagem() {
        List<Produtos> listaContas = (List<Produtos>) er.findAll();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("produto/lista_Produto");
        modelAndView.addObject("produtos", listaContas);
        return modelAndView;
    }

    @RequestMapping(value = {"/novo"}, method = RequestMethod.GET)
    public ModelAndView formulario() {
        ModelAndView modelAndView = new ModelAndView();
        Produtos evento = new Produtos();
        modelAndView.setViewName("/produto/formCadastro");
        modelAndView.addObject("produtoN",evento);
        return modelAndView;
    }

    @RequestMapping(value = {"/editar/{id}"}, method = RequestMethod.GET)
    public ModelAndView alterar(@PathVariable("id") long id) {
        ModelAndView modelAndView = new ModelAndView();
       
        Produtos evento = er.findById(id).get();        
        
        modelAndView.addObject("produtoN", evento);
        modelAndView.setViewName("/produto/formCadastro");
        return modelAndView;
    }

    @RequestMapping(value = {"/excluir/{id}"}, method = RequestMethod.GET)
    public String excluir(@PathVariable("id") long id) {
        
        Produtos conta = er.findById(id).get();
        er.delete(conta);
        return "redirect:/lista"; 
    }

    @RequestMapping(value = {"/salvar"}, method = RequestMethod.POST)
    public String form(Produtos evento) {
    	
		er.save(evento);
		return "redirect:/lista";
		
	}

	

}
